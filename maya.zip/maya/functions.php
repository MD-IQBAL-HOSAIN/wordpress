<?php

// Add default posts and comments RSS feed links to head.
add_theme_support('automatic-feed-links');

/*
 * Let WordPress manage the document title.
 * By adding theme support, we declare that this theme does not use a
 * hard-coded <title> tag in the document head, and expect WordPress to
 * provide it for us.
 */
add_theme_support('title-tag');

add_theme_support('post-formats', array('gallery', 'quote', 'video', 'aside', 'image', 'link', 'audio', 'status', 'chat'));

/*
 * Enable support for Post Thumbnails on posts and pages.
 *
 */
add_theme_support('post-thumbnails');



//Add selective refresh for sidebar widget
add_theme_support('customize-selective-refresh-widgets');

// woocommerce support
add_theme_support('woocommerce');

/**
 * Custom background support.
 */
add_theme_support('custom-background', apply_filters('news_custom_background_args', array(
	'default-color' => 'ffffff',
	'default-image' => '',
)));

/*
 * Switch default core markup for search form, comment form, and comments
 * to output valid HTML5.
 */
add_theme_support('html5', array(
	'search-form',
	'comment-form',
	'comment-list',
	'gallery',
	'caption',
));
add_theme_support('post-thumbnails');
add_theme_support('custom-header');
add_theme_support('custom-logo');
add_theme_support('editor-styles');
add_theme_support('align-wide');
add_theme_support('html5', array('navigation-widgets'));
add_theme_support('wp-block-styles');
add_theme_support('custom-background');
add_theme_support('post-thumbnails');





add_action('init', 'prowp_register_my_post_types');
function prowp_register_my_post_types()
{

	register_post_type(
		'notice',
		array(
			'public' => true,
			'labels' => array('name' => 'Notice',),
			'taxonomies' => array('category', 'Course', 'post_tag'),
			'supports' => array('title', 'editor', 'author', 'thumbnail', 'comments', 'custom-fields')
		)
	);
	register_post_type(
		'results',
		array(
			'labels' => array('name' => 'Results'),
			'taxonomies' => array('post_tag'),
			'public' => true,
			'supports' => array('title', 'editor', 'author', 'thumbnail', 'comments')
		)
	);
	register_post_type(
		'carousel',
		array(
			'public' => true,
			'labels' => array('name' => 'Carousel',),
			'taxonomies' => array('category', 'Course', 'post_tag'),
			'supports' => array('title', 'editor', 'thumbnail', 'excerpt')
		)
	);
}

//CUSTOM TAXONOMY
//hook into the init action and call create_book_taxonomies when it fires
add_action('init', 'create_topics_hierarchical_taxonomy', 0);
//create a custom taxonomy name it topics for your posts
function create_topics_hierarchical_taxonomy()
{
	// Add new taxonomy, make it hierarchical like categories
	//first do the translations part for GUI
	$labels = array(
		'name' => _x('Course', 'taxonomy general name'),
		'singular_name' => _x('Course', 'taxonomy singular name'),
		'search_items' => __('Search Course'),
		'all_items' => __('All Course'),
		'parent_item' => __('Parent Course'),
		'parent_item_colon' => __('Parent Course:'),
		'edit_item' => __('Edit Course'),
		'update_item' => __('Update Course'),
		'add_new_item' => __('Add New Course'),
		'new_item_name' => __('New Course Name'),
		'menu_name' => __('Course'),
	);
	// Now register the taxonomy
	register_taxonomy('Course', array('post'), array(
		'hierarchical' => true,
		'labels' => $labels,
		'show_ui' => true,
		'show_in_menu' => true,
		'show_in_rest' => true,
		'show_admin_column' => true,
		'query_var' => true,
		'rewrite' => array('slug' => 'topic'),
	));
}
?>
<?php
/**
 * Register our sidebars and widgetized areas.
 *
 */
function arphabet_widgets_init()
{

	register_sidebar(array(
		'name'          => 'Home right sidebar',
		'id'            => 'home_right_1',
		'before_widget' => '<div>',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 class="rounded">',
		'after_title'   => '</h2>',
	));
	register_sidebar(array(
		'name'          => 'Footer Middle',
		'id'            => 'footer_middle',
		'before_widget' => '<div>',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 class="rounded">',
		'after_title'   => '</h2>',
	));
	register_sidebar(array(
		'name'          => 'Footer Right',
		'id'            => 'footer_right',
		'before_widget' => '<div>',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 class="rounded">',
		'after_title'   => '</h2>',
	));
	register_sidebar(array(
		'name'          => 'Footer Left',
		'id'            => 'footer_left',
		'before_widget' => '<div>',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 class="rounded">',
		'after_title'   => '</h2>',
	));
}
add_action('widgets_init', 'arphabet_widgets_init');
?>

<!-- ............................................................................................................. -->
<?php
function newspaper_theme_setup()
{
	/*
		* Make theme available for translation.
		* Translations can be filed in the /languages/ directory.
		* If you're building a theme based on newspaper theme, use a find and replace
		* to change 'newspaper-theme' to the name of your theme in all the template files.
		*/
	load_theme_textdomain('newspaper-theme', get_template_directory() . '/languages');

	// Add default posts and comments RSS feed links to head.
	add_theme_support('automatic-feed-links');

	/*
		* Let WordPress manage the document title.
		* By adding theme support, we declare that this theme does not use a
		* hard-coded <title> tag in the document head, and expect WordPress to
		* provide it for us.
		*/
	add_theme_support('title-tag');

	/*
		* Enable support for Post Thumbnails on posts and pages.
		*
		* @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		*/
	add_theme_support('post-thumbnails');

	// This theme uses wp_nav_menu() in one location.

	//my nav menue start

	register_nav_menus(
		array(
			'menu-1' => esc_html__('Primary', 'newspaper-theme'),
		)
	);
	//my nav menue end


	/*
		* Switch default core markup for search form, comment form, and comments
		* to output valid HTML5.
		*/
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	// Set up the WordPress core custom background feature.
	add_theme_support(
		'custom-background',
		apply_filters(
			'newspaper_theme_custom_background_args',
			array(
				'default-color' => 'ffffff',
				'default-image' => '',
			)
		)
	);

	// Add theme support for selective refresh for widgets.
	add_theme_support('customize-selective-refresh-widgets');

	/**
	 * Add support for core custom logo.
	 *
	 */
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		)
	);
}
add_action('after_setup_theme', 'newspaper_theme_setup');

///////////////////////////////////////////////////////////////////////////////


